This is a "Hello world" skeleton application which can be used as a
starting point for Zephyr application development using mcuboot.

It includes the configuration "glue" needed to make the application
loadable by mcuboot in addition to a basic Zephyr hello world
application's code.
