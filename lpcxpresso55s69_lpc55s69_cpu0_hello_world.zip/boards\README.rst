You can place per-board configuration here. See the comments in the
CMakeLists.txt for more information.
